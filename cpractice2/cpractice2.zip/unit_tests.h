// unit_tests.h
// Larry Kiser October 30, 2015

// the main unit test
extern int test( void ) ;

// boolean assert function for unit testing
extern int assert( int testresult, char error_message[], ... ) ;
